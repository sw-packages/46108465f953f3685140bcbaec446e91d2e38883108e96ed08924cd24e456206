// http://www.medicalconnections.co.uk/wiki/UID_Rules
"1.2.826.0.1.3680043.2.1143", "GDCM"
